# 爱特PHP文件专家(php control panel)
很强大的一个PHP文件管理器

## 系统兼容
PHP 5.3 + (需要session扩展支持)

## 自动构建
下载CI自动构建的程序压缩包: [fileadmin.zip](https://aite.xyz/product/fileadmin.zip)
